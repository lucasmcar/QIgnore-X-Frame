$(document).on("submit", "#meuform",function (e) {
    e.preventDefault();

    var meuform = $(this);

    $.ajax({
       type: "POST",
       url: meuform.attr("action"), //Pega o action do FORM
       data: meuform.serialize() //Pega os campos do FORM
   }).done(function (resposta) {
        alert(resposta); //Exibe a resposta
   }).fail(function (xhr, status) {
        alert("erro:" + status); //Exibe na requisição Ajax
   });
});
